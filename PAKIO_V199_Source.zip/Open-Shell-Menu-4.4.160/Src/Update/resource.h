//{{NO_DEPENDENCIES}}
// Microsoft Visual C++ generated include file.
// Used by Update.rc
//
#define IDI_APPICON                     101
#define IDC_STATICLATEST                1001
#define IDC_EDITTEXT                    1002
#define IDC_BUTTONDOWNLOAD              1003
#define IDC_CHECKDONT                   1004
#define IDC_BUTTONCHECKNOW              1005
#define IDC_CHECKAUTOCHECK              1006
#define IDC_CHECKNIGHTLY                1007
#define IDD_UPDATE                      6001
#define IDS_UPDATED                     6001
#define IDS_OUTOFDATE                   6002
#define IDS_NEWVERSION                  6003
#define IDS_UPDATE_FAIL                 6005
#define IDS_LANG_OUTOFDATE              6006
#define IDS_LANG_NEWVERSION             6007

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        228
#define _APS_NEXT_COMMAND_VALUE         32769
#define _APS_NEXT_CONTROL_VALUE         262
#define _APS_NEXT_SYMED_VALUE           106
#endif
#endif
