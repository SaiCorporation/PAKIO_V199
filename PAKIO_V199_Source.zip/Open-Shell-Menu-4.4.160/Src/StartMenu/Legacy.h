// import legacy Classic Shell settings/data if we don't have any yet
void ImportLegacyData();
