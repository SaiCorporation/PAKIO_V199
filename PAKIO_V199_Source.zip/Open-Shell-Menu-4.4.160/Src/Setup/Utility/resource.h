//{{NO_DEPENDENCIES}}
// Microsoft Visual C++ generated include file.
// Used by Utility.rc
//
#define IDI_ICON1                       101
#define IDD_DIALOG1                     102
#define IDD_COLORS                      102
#define IDD_UNINSTALL                   103
#define IDD_UNINSTALL_RESULTS           104
#define IDD_UNINSTALL_PROGRESS          105
#define IDD_LOGSETTINGS                 106
#define IDC_EDIT1                       1001
#define IDC_SPIN1                       1002
#define IDC_LIST1                       1003
#define IDC_EDIT2                       1004
#define IDC_BUTTONBROWSEPATH            1005
#define IDC_CHECKADMIN                  1006
#define IDC_CHECKSETTINGS               1007
#define IDC_CHECKALLUSERS               1008
#define IDC_SYSLINK1                    1009
#define IDC_EDITPATH                    1010
#define IDC_SYSLINKSTARTUP              1010
#define IDC_STATICPATH                  1011
#define IDC_SYSLINKEXPLORER             1011
#define IDC_STATICWARNING               1012
#define IDC_SYSLINKIE                   1012
#define IDC_STATICRESULT                1013
#define IDC_EDITRESULT                  1014
#define IDC_BUTTONREBOOT                1015
#define IDC_BUTTONCLOSE                 1016
#define IDC_PROGRESS1                   1017
#define IDC_STATICWIAT                  1018
#define IDC_STATICWAIT                  1018
#define IDC_STATICALLUSERS              1019
#define IDC_CHECKEXPLORER               1020
#define IDC_CHECKSTARTUP                1022
#define IDC_CHECKIE                     1023
#define IDC_CHECKEXECUTE                1028
#define IDC_CHECKOPEN                   1029
#define IDC_CHECKITEMS                  1030
#define IDC_CHECKMOUSE                  1031
#define IDC_CHECKMFU                    1032
#define IDC_CHECKSEARCH                 1033
#define IDC_CHECKSEARCH_SQL             1034
#define IDC_CHECKNEW                    1035
#define IDC_CHECKAPPS                   1036
#define IDC_CHECKCACHE                  1037
#define IDC_SYSLINKSTART                1038
#define IDC_SYSLINKSTART2               1039
#define IDC_SYSLINKCACHE                1039

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        108
#define _APS_NEXT_COMMAND_VALUE         40001
#define _APS_NEXT_CONTROL_VALUE         1039
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
