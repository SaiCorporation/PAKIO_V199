//{{NO_DEPENDENCIES}}
// Microsoft Visual C++ generated include file.
// Used by Setup.rc
//
#define IDS_APP_NAME                    100
#define IDS_APP_TITLE                   100
#define IDI_APPICON                     101
#define IDS_ERR_CORRUPTED               102
#define IDR_MSI_FILE32                  132
#define IDR_MSI_FILE64                  164
#define IDS_ERR_INTERNAL                166
#define IDS_ERR_EXTRACT                 167
#define IDR_MSI_CHECKSUM                167
#define IDS_ERR_WIN7                    169
#define IDS_ERR_MSIEXEC                 170
#define IDS_HELP                        200
#define IDC_EDIT1                       1001
#define IDC_EDITPWD                     1001

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        168
#define _APS_NEXT_COMMAND_VALUE         40001
#define _APS_NEXT_CONTROL_VALUE         1002
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
